import React from "react";

export type WorkoutDetails = {
    workoutName: string,
    duration: number,
    exerciseType: string,
    calories: number

}
